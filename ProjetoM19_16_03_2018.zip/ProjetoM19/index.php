<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Página Inicial</title>
  
  
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>


      <link rel="stylesheet" href="css/style.css">

<!-- ____________________ LOGIN ____________________________________ -->
  <?php 
    require('ligaBD.php');
    if (isset($_POST['userlog']) and isset($_POST['passlog'])){

        $username = $_POST['userlog'];
        $password = $_POST['passlog'];
        $query = "SELECT * FROM utilizadores WHERE Username='$username' and Password='$password'";
        
        $result = mysql_query($query, $ligaBD) or die(mysql_error($ligaBD));
        $count = mysql_num_rows($result);

        if ($count == 0)
            {
                echo "<script>alert('Username ou Password erradas.');</script>";
                
            }

        else
            {
				$count = mysql_fetch_array($result);
				Session_start();
 				$_SESSION["Username"]=$count["Username"];
				header("location: main/news.php");
            }
    }


?>

<!-- ____________________ REGISTER ____________________________________ -->

<?php 

    require('ligaBD.php');
    if (isset($_POST['userz']) and isset($_POST['passz'])){
	$user=$_POST['userz'];
    $pass1=$_POST['passz'];
    $pass2=$_POST['repassz'];
	$email=$_POST['emailz'];

	if($pass1!=$pass2)
        {
            echo "<script>alert('As passwords não correspondem!');</script>";
        }

	else{

        include("ligaBD.php");
        $existe="select * from utilizadores where Email='".$email."' Or Username='".$user."'";
        $faz_existe = mysql_query ($existe, $ligaBD );
        if(!$faz_existe)
        {
            echo 'Erro';
        } 

		else{

            if(mysql_num_rows($faz_existe) == 0)
                {
                    $insere_aluno = "insert into utilizadores values('".$email."','".$user."','".$pass1."')";
                    $faz_insere_aluno = mysql_query($insere_aluno, $ligaBD );
                    echo "<script>alert('O utilizador foi registado com sucesso!');</script>";
                }  

			else
                {
                    echo "<script>alert('Este utilizador já se encontra registado!');</script>";
                }
            }
        }
    } 

?>

<!--_____________________________________________________________________ -->



</head>

<body>

  <div class="login-wrap" style="margin-top: 120px">
	<div class="login-html">
		<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Login</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Registo</label>
		<div class="login-form" style="margin-top: 30px">
			<form method="POST" action="index.php">
				<div class="sign-in-htm">
					<div class="group">
						<label for="user" class="label">Username</label>
						<input name="userlog" type="text" class="input" required>
					</div>
					<div class="group">
						<label for="pass" class="label">Password</label>
						<input name="passlog" type="password" class="input" data-type="password" required>
					</div>
					<div class="group">
						<input id="check" type="checkbox" class="check" checked>
						<label for="check"><span class="icon"></span> Lembrar-me</label>
					</div>
					<div class="group">
						<input style="cursor: pointer" type="submit" class="button" value="Entrar">
					</div>
					<div class="hr" style="margin-top: 40px"></div>
					<div class="foot-lnk">
						<a href="#forgot">Esqueceu-se da password?</a>
					</div>
				</div>
			</form>
			<form method="POST" action="index.php">
				<div class="sign-up-htm">
					<div class="group">
						<label for="user" class="label">Username</label>
						<input name="userz" type="text" class="input" required>
					</div>
					<div class="group">
						<label for="pass" class="label">Password</label>
						<input name="passz" type="password" class="input" data-type="password" required required required>
					</div>
					<div class="group">
						<label for="repass" class="label">Repetir Password</label>
						<input name="repassz" type="password" class="input" data-type="password" required required>
					</div>
					<div class="group">
						<label for="email" class="label">Email</label>
						<input name="emailz" type="email" class="input" required>
					</div><br>
					<div class="group">
						<input style="cursor: pointer" type="submit" class="button" value="Registar">
					</div>
					<div class="hr" style="margin-top: 40px"></div>
					<div class="foot-lnk" style="margin-top: -20px">
						<label for="tab-1">Já tem uma conta?</a>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
  
  


</body>


</html>
