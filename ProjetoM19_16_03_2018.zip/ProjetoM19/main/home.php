<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<?php 
		include("validar.php");
	?>

<style>
	ul {
	    list-style-type: none;
	    margin: 0;
	    padding: 0;
	    overflow: hidden;
	    background-color: #3f4277;
	}

	li {
	    float: left;
	}

	li a {
	    display: block;
	    color: white;
	    text-align: center;
	    padding: 14px 16px;
	    text-decoration: none;
	}

	li a:hover:not(.active) {
	    background-color: #5357ad;
	}

	.active {
	    background-color: #6f75e2;
	}
	body{
	  color: black;
	  font-family:verdana;
	  margin: 0;
	}
</style>
<!--http://shops-weight.gq/img/starenhoumet.png-->
<!-- style="background: url(http://www.scottelectrical.co.nz/media/wysiwyg/data_suppliers.jpg) no-repeat; background-size: cover; font-family: 'Open Sans',sans-serif"-->
</head>
<body background="img/bck_tt.jpg">
	<!--<link rel="stylesheet" href="css/form.css">-->
	<ul>
  	<li><a class="active" href="#">Home</a></li>
  	<li><a href="news.php">News</a></li>
  	<li><a href="#">Contact</a></li>
  	<li><a href="#">About</a></li>
	<li><a href="logout.php" style="float:right;">Terminar Sess&atildeo</a></li>
  	</ul>
</body>
</html>