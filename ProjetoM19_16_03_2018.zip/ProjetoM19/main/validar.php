<?php
    Session_start();
    if(!isset($_SESSION['Username']))
    {
        echo "Página reservada a utilizadores registados!!!";
        exit;
    }
?>